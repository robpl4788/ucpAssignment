/* Supplied by Curtin Staff */

#ifndef RANDOM_H
#define RANDOM_H

void initRandom();
int randomUCP(int low, int high);

#endif
