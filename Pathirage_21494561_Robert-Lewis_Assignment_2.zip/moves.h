#ifndef PLAYERMOVE_H
#define PLAYERMOVE_H

#include "constants.h"
#include "linkedList.h"

int takeTurn(BoardState* pBoard, LinkedList* pastBoards);

#endif