#ifndef PRINTBOARD_H
#define PRINTBOARD_H

#include "constants.h"

void printBoard(BoardState board);

#endif