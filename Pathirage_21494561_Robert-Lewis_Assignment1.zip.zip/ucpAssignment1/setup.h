#ifndef SETUP_H
#define SETUP_H

int validateInputs(int* pRows, int* pCols, int* pArgc, char* argv[]);
void initialiseCars(int* carPositions, int* carDirections, int roadCount, int columns);


#endif