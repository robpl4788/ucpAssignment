#ifndef PLAYERMOVE_H
#define PLAYERMOVE_H

#include "constants.h"

int makeMove(int rows, int columns, int roadCount, vector2d* pPlayerPosition, int* carPositions, int* carDirections);

#endif